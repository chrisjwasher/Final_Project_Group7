import os
import sys
import traceback
import numpy as np
import torch
import librosa
from transformers import Wav2Vec2FeatureExtractor, HubertModel
from tensorflow.keras.models import load_model
from sklearn.preprocessing import LabelEncoder

# List of audio file paths to test
audio_file_paths = [
    "/home/ubuntu/Final_Project_Deeplearning/Highlights_debate_emotion_clip_1.mp3",
    "/home/ubuntu/Final_Project_Deeplearning/Highlights_debate_emotion_clip_2.mp3",
    "/home/ubuntu/Final_Project_Deeplearning/Highlights_debate_emotion_clip_3.mp3",
    "/home/ubuntu/Final_Project_Deeplearning/Highlights_debate_emotion_clip_4.mp3",
    "/home/ubuntu/Final_Project_Deeplearning/Highlights_debate_emotion_clip_5.mp3",
    "/home/ubuntu/Final_Project_Deeplearning/Highlights_debate_emotion_clip_6.mp3",
    "/home/ubuntu/Final_Project_Deeplearning/Highlights_debate_emotion_clip_7.mp3",
    "/home/ubuntu/Final_Project_Deeplearning/Highlights_debate_emotion_clip_8.mp3",
    "/home/ubuntu/Final_Project_Deeplearning/Highlights_debate_emotion_clip_9.mp3",
    "/home/ubuntu/Final_Project_Deeplearning/Highlights_debate_emotion_clip_10.mp3"

]

# Load HuBERT
feature_extractor = Wav2Vec2FeatureExtractor.from_pretrained("facebook/hubert-large-ls960-ft")
hubert_model = HubertModel.from_pretrained("facebook/hubert-large-ls960-ft")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
hubert_model.to(device)

def extract_features(file_path):
    try:
        # Load audio
        audio_input, _ = librosa.load(file_path, sr=16000)
        if not isinstance(audio_input, np.ndarray):
            audio_input = np.array(audio_input)

        # Extract features using HuBERT
        inputs = feature_extractor(audio_input, sampling_rate=16000, return_tensors="pt", padding=True)
        inputs = {key: val.to(device) for key, val in inputs.items()}
        with torch.no_grad():
            outputs = hubert_model(**inputs)
        # Average last hidden states over time
        last_hidden_states = outputs.last_hidden_state
        feature = last_hidden_states.mean(dim=1).cpu().numpy().flatten()
        return feature
    except Exception as e:
        print(f"Error encountered while parsing file: {file_path}")
        traceback.print_exc()
        return None

# Load the pre-trained classification model
model_path = "emotion_recognition_using_Hubertmodel.h5"
if not os.path.exists(model_path):
    print(f"Model file {model_path} not found. Make sure it's in the current directory.")
    sys.exit(1)

keras_model = load_model(model_path)

# The classes should be the same as used during training
classes = ["ANG", "DIS", "FEA", "HAP", "NEU", "SAD"]
encoder = LabelEncoder()
encoder.fit(classes)

# Iterate through each audio file and predict its emotion
for audio_file_path in audio_file_paths:
    print(f"Processing file: {audio_file_path}")
    test_feature = extract_features(audio_file_path)
    if test_feature is None:
        print(f"Failed to extract features for {audio_file_path}. Skipping.")
        continue

    X_test = np.array([test_feature])



    # Make a prediction
    y_pred = keras_model.predict(X_test)
    y_pred_class = np.argmax(y_pred, axis=1)
    predicted_emotion = encoder.inverse_transform(y_pred_class)[0]

    print(f"Predicted Emotion for {os.path.basename(audio_file_path)}: {predicted_emotion}")